// Import external libraries
import compromise from 'compromise';
import Web3 from 'web3';

// Enhanced speech recognition setup
window.SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const recognition = new SpeechRecognition();

recognition.onstart = () => updateStatus("Listening for your command...");

recognition.onspeechend = () => {
    updateStatus("Processing...");
    recognition.stop();
};

recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    confirmAndProcessCommand(transcript);
};

// Function to update status message
function updateStatus(message) {
    document.getElementById("status").textContent = message;
}

// Function to confirm command with user
function confirmAndProcessCommand(transcript) {
    const confirmMessage = `Did you say: ${transcript}?`;
    if (confirm(confirmMessage)) {
        processCommand(transcript);
    } else {
        updateStatus("Command cancelled.");
    }
}

// Initialize Web3 and connect to MetaMask
async function initializeWeb3() {
    try {
        // Detect MetaMask provider
        const provider = await detectEthereumProvider();
        if (!provider) {
            throw new Error("Please install MetaMask!");
        }

        // Create Web3 instance
        const web3 = new Web3(provider);

        // Request account access if needed
        await provider.request({ method: 'eth_requestAccounts' });

        // Check if the network is Moonbase Alpha
        const networkId = await web3.eth.net.getId();
        const moonbaseNetworkId = 1287; // Moonbase Alpha Chain ID

        if (networkId !== moonbaseNetworkId) {
            throw new Error("Please switch to the Moonbase Alpha network in MetaMask.");
        }

        return web3;
    } catch (error) {
        alert(error.message);
        throw error;
    }
}

// Process Commands
async function processCommand(command) {
    try {
        const web3 = await initializeWeb3();
        const accounts = await web3.eth.getAccounts();
        const account = accounts[0]; // Using the first account from MetaMask

        const { amount, recipient, action } = parseCommand(command);

        if (action === "check balance") {
            const balance = await web3.eth.getBalance(recipient || account); // Check balance for the recipient or the user's account
            const etherBalance = web3.utils.fromWei(balance, 'ether');
            updateStatus(`Balance: ${etherBalance} ETH`);
        } else if (amount && recipient) {
            const weiAmount = web3.utils.toWei(amount, 'ether');

            if (web3.utils.isAddress(recipient)) {
                sendTransaction(web3, account, recipient, weiAmount);
            } else {
                updateStatus("Invalid address format.");
            }
        } else {
            updateStatus("Invalid command.");
        }
    } catch (error) {
        updateStatus(`Error: ${error.message}`);
    }
}

// Parse the command to extract amount, recipient, and action
function parseCommand(command) {
    const doc = compromise(command);
    const amount = doc.match('#Number').text();
    const recipient = doc.match('#Hash').text();
    const action = doc.match('check balance').found ? 'check balance' : null;
    return { amount, recipient, action };
}

// Send the transaction
function sendTransaction(web3, from, to, value) {
    web3.eth.sendTransaction({ from, to, value })
        .on('transactionHash', (hash) => updateStatus(`Transaction sent! Hash: ${hash}`))
        .on('error', (error) => updateStatus(`Error: ${error.message}`));
}

// Start Voice Recognition
document.getElementById("start-record-btn").addEventListener("click", () => recognition.start());