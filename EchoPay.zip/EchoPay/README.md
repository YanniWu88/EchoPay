# Voice Payment App

A voice-activated payment application using MetaMask and Web3.js.

## Features


Voice Command Recognition:

Listening Mode: The application can enter a listening mode to capture voice commands using the Web Speech API.
Speech to Text Conversion: Converts spoken words into text for further processing.
Command Confirmation:

User Confirmation: After capturing a voice command, the application confirms the command with the user to avoid any accidental transactions.
Command Processing: Only processes commands that are confirmed by the user.
MetaMask Integration:

MetaMask Detection: Detects if MetaMask is installed in the user's browser.
Account Access Request: Requests access to the user's MetaMask account.
Network Verification: Ensures that the user is connected to the Moonbase Alpha network (or any other specified Ethereum network).
Error Handling: Alerts the user if MetaMask is not installed or if the wrong network is selected.
Ethereum Transactions:

Send Transactions: Allows users to send Ethereum transactions by specifying the amount and recipient address through voice commands.
Transaction Feedback: Provides feedback on the transaction status, including transaction hash and error messages.
Balance Checking:

Check Balance: Allows users to check the balance of their own account or any specified Ethereum address using voice commands.
Balance Display: Displays the balance in Ether (ETH) to the user.
Natural Language Processing (NLP):

Command Parsing: Uses the compromise library to parse and extract relevant information (amount, recipient address, action) from the voice command.
User Interface (UI):

Status Updates: Provides real-time feedback to the user through status messages displayed on the web page.
Interactive Button: A button to start the voice recognition process.


Steps to Create the Project
Create Project Directory:

mkdir voicepay
cd voicepay
Initialize Node.js Project:

npm init -y
Install Dependencies:

npm install compromise web3
Create index.html:

touch index.html
Create script.js:

touch script.js
Add Content to index.html and script.js:

Copy the provided content into the respective files.
Serve the Project:

Using Python or any other simple HTTP server:
python -m http.server
Open your browser and navigate to http://localhost:8000.
Summary
By following these steps, you set up a basic file structure for your project, install necessary dependencies, and create HTML and JavaScript files to implement the functionality. This structure allows you to develop, test, and extend your voice-activated Ethereum transaction application.