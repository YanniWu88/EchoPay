// Example test using Jest or Mocha
describe('Voice Command Tests', () => {
    test('should correctly parse amount and address from voice command', () => {
        const command = "send 0.1 ether to 0x1234567890abcdef1234567890abcdef12345678";
        const expected = {
            amount: '0.1',
            address: '0x1234567890abcdef1234567890abcdef12345678'
        };
        const result = parseCommand(command);
        expect(result).toEqual(expected);
    });
});